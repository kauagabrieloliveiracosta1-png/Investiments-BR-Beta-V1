import 'package:flutter/material.dart';

void main() => runApp(const InvestimentsApp());

const navy = Color(0xFF101B2D);
const panel = Color(0xFF192840);
const green = Color(0xFF36C98F);
const muted = Color(0xFF9BAAC0);

class InvestimentsApp extends StatelessWidget {
  const InvestimentsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Investiments BR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: green,
          brightness: Brightness.dark,
          surface: panel,
        ),
        cardTheme: CardTheme(
          color: panel,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFF293A53)),
          ),
        ),
      ),
      home: const AgencyHome(),
    );
  }
}

class AgencyHome extends StatefulWidget {
  const AgencyHome({super.key});

  @override
  State<AgencyHome> createState() => _AgencyHomeState();
}

class _AgencyHomeState extends State<AgencyHome> {
  int tab = 0;
  double cash = 500000;
  int clients = 0;
  int reputation = 1;
  final Set<String> signed = {};

  final prospects = const [
    Prospect('Lucas Nascimento', 'MEI', 19, 'Brasil', 'Sub-20', 180000, 68, 'Técnico e criativo'),
    Prospect('Matheus Oliveira', 'ATA', 21, 'Brasil', 'Série B', 420000, 72, 'Atacante de profundidade'),
    Prospect('Enzo Ferreira', 'VOL', 18, 'Argentina', 'Sub-20', 250000, 70, 'Boa leitura de jogo'),
    Prospect('João Pedro Lima', 'LE', 22, 'Brasil', 'Série C', 160000, 65, 'Lateral ofensivo'),
  ];

  String money(double value) {
    final s = value.toStringAsFixed(0);
    final out = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      out.write(s[i]);
      final remaining = s.length - i - 1;
      if (remaining > 0 && remaining % 3 == 0) out.write('.');
    }
    return 'R\$ $out';
  }

  void sign(Prospect p) {
    if (signed.contains(p.name)) return;
    const cost = 15000.0;
    if (cash < cost) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Capital insuficiente para concluir a prospecção.')),
      );
      return;
    }
    setState(() {
      cash -= cost;
      clients++;
      reputation = (reputation + 2).clamp(1, 100);
      signed.add(p.name);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${p.name} agora faz parte da carteira da Investiments BR!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      dashboard(),
      market(),
      portfolio(),
      finances(),
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy,
        titleSpacing: 20,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('INVESTIMENTS BR', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.3)),
            Text('FOOTBALL AGENCY', style: TextStyle(fontSize: 9, color: muted, letterSpacing: 2)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Notificações',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Você está em dia com as notificações.')),
            ),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        backgroundColor: const Color(0xFF0B1422),
        indicatorColor: green.withOpacity(.18),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_rounded), label: 'Painel'),
          NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Mercado'),
          NavigationDestination(icon: Icon(Icons.groups_rounded), label: 'Atletas'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_rounded), label: 'Finanças'),
        ],
      ),
    );
  }

  Widget dashboard() => ListView(
    padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            colors: [Color(0xFF1D3C4A), Color(0xFF192840), Color(0xFF172237)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: green.withOpacity(.25)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.shield_moon_rounded, color: green, size: 28),
            const SizedBox(width: 9),
            const Text('AGÊNCIA FUNDADA', style: TextStyle(color: green, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.2)),
            const Spacer(),
            const Text('2026', style: TextStyle(color: muted, fontWeight: FontWeight.w600)),
          ]),
          const SizedBox(height: 22),
          const Text('Sua próxima\ngrande contratação começa aqui.', style: TextStyle(fontSize: 23, height: 1.18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          const Text('Construa reputação. Descubra talentos. Faça negócios.', style: TextStyle(color: muted, fontSize: 12)),
        ]),
      ),
      const SizedBox(height: 18),
      const SectionTitle('RESUMO DA AGÊNCIA'),
      const SizedBox(height: 10),
      GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.65,
        children: [
          MetricCard(label: 'CAPITAL DISPONÍVEL', value: money(cash), icon: Icons.payments_outlined, color: green),
          MetricCard(label: 'ATLETAS NA CARTEIRA', value: '$clients', icon: Icons.groups_outlined),
          MetricCard(label: 'REPUTAÇÃO', value: '$reputation / 100', icon: Icons.stars_rounded),
          const MetricCard(label: 'SEDE', value: 'Brasil', icon: Icons.location_on_outlined),
        ],
      ),
      const SizedBox(height: 20),
      const SectionTitle('AGENDA DE HOJE'),
      Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: green.withOpacity(.13), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.event_note_rounded, color: green)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('02 de novembro de 2026', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 4),
            Text('Sua primeira missão: encontrar e avaliar o primeiro atleta para representar.', style: TextStyle(color: muted, fontSize: 12, height: 1.4)),
          ])),
        ]),
      )),
      const SizedBox(height: 16),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 15)),
        onPressed: () => setState(() => tab = 1),
        icon: const Icon(Icons.travel_explore_rounded),
        label: const Text('EXPLORAR MERCADO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .5)),
      ),
      const SizedBox(height: 8),
      const Text('Versão inicial demonstrativa • Os atletas exibidos são personagens fictícios de teste.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 10)),
    ],
  );

  Widget market() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Mercado de atletas', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      const Text('Observe oportunidades e monte sua carteira.', style: TextStyle(color: muted)),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: green.withOpacity(.09), borderRadius: BorderRadius.circular(14), border: Border.all(color: green.withOpacity(.2))),
        child: const Row(children: [
          Icon(Icons.info_outline, color: green),
          SizedBox(width: 10),
          Expanded(child: Text('Amostra de demonstração: nomes e avaliações fictícios. O banco de dados real será integrado em uma próxima etapa.', style: TextStyle(fontSize: 11, height: 1.4))),
        ]),
      ),
      const SizedBox(height: 14),
      ...prospects.map((p) => ProspectCard(
        prospect: p,
        isSigned: signed.contains(p.name),
        onSign: () => sign(p),
      )),
    ],
  );

  Widget portfolio() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Minha carteira', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Atletas oficialmente representados pela agência.', style: TextStyle(color: muted)),
      const SizedBox(height: 16),
      if (signed.isEmpty)
        const EmptyState(icon: Icons.groups_2_outlined, title: 'Nenhum atleta contratado', subtitle: 'Visite o mercado para encontrar seu primeiro cliente.')
      else
        ...prospects.where((p) => signed.contains(p.name)).map((p) => ProspectCard(prospect: p, isSigned: true, onSign: () {})),
    ],
  );

  Widget finances() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Finanças', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Controle o caixa e os custos operacionais.', style: TextStyle(color: muted)),
      const SizedBox(height: 18),
      Card(child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('SALDO ATUAL', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1)),
          const SizedBox(height: 8),
          Text(money(cash), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: green)),
          const Divider(height: 28, color: Color(0xFF34445A)),
          const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Capital inicial'), Text('R\$ 500.000')]),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Prospecção e contratação'), Text('- ${money(500000 - cash)}', style: const TextStyle(color: Colors.orangeAccent))]),
          const SizedBox(height: 12),
          const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Dívidas'), Text('R\$ 0', style: TextStyle(color: green))]),
        ]),
      )),
      const SizedBox(height: 12),
      const Text('Cada contratação demonstrativa desconta R\$ 15.000 do caixa. Receitas de comissão serão implementadas nas próximas versões.', style: TextStyle(color: muted, fontSize: 12, height: 1.5)),
    ],
  );
}

class Prospect {
  final String name, position, country, level, profile;
  final int age, rating;
  final double value;
  const Prospect(this.name, this.position, this.age, this.country, this.level, this.value, this.rating, this.profile);
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.2));
}

class MetricCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const MetricCard({super.key, required this.label, required this.value, required this.icon, this.color = Colors.white});
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(13),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Icon(icon, color: color, size: 19),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: color)),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: muted, fontSize: 9, letterSpacing: .6)),
      ]),
    ]),
  ));
}

class ProspectCard extends StatelessWidget {
  final Prospect prospect;
  final bool isSigned;
  final VoidCallback onSign;
  const ProspectCard({super.key, required this.prospect, required this.isSigned, required this.onSign});

  String money(double v) => 'R\$ ${v.toStringAsFixed(0)}';

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 11),
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 23, backgroundColor: green.withOpacity(.14), child: Text(prospect.position, style: const TextStyle(color: green, fontWeight: FontWeight.w900, fontSize: 11))),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(prospect.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            Text('${prospect.age} anos • ${prospect.country} • ${prospect.level}', style: const TextStyle(color: muted, fontSize: 11)),
          ])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: green.withOpacity(.13), borderRadius: BorderRadius.circular(9)), child: Text('${prospect.rating} OVR', style: const TextStyle(color: green, fontWeight: FontWeight.w900, fontSize: 11))),
        ]),
        const SizedBox(height: 13),
        Text(prospect.profile, style: const TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 12),
        Row(children: [
          const Text('Valor estimado ', style: TextStyle(color: muted, fontSize: 11)),
          Text(money(prospect.value), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          const Spacer(),
          if (isSigned)
            const Chip(label: Text('NA CARTEIRA'), visualDensity: VisualDensity.compact, labelStyle: TextStyle(fontSize: 9, color: green))
          else
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: navy, visualDensity: VisualDensity.compact),
              onPressed: onSign,
              child: const Text('Prospectar', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
            ),
        ]),
      ]),
    ),
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 70),
    child: Column(children: [
      Icon(icon, size: 55, color: muted),
      const SizedBox(height: 15),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
      const SizedBox(height: 7),
      Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: muted, fontSize: 12)),
    ]),
  );
}
