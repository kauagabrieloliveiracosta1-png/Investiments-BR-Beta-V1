# Investiments BR — projeto Flutter

Protótipo inicial do simulador de empresário de futebol para Android.

## O que já funciona
- Painel da agência com capital, reputação e número de atletas.
- Navegação entre Painel, Mercado, Atletas e Finanças.
- Lista de atletas fictícios para demonstração.
- Ação de prospectar/contratar, com desconto no caixa.
- Atualização da carteira e reputação durante a sessão.

## Importante
Os nomes, avaliações e valores dos atletas da tela Mercado são dados fictícios de teste. Ainda não existe integração com uma base de dados de jogadores reais, notícias, clubes ou transferências. O salvamento persistente, contratos, comissões e negociações com clubes também são etapas futuras.

## Como gerar o APK
É necessário instalar Flutter SDK, Android Studio e Android SDK.

1. Extraia o ZIP.
2. Abra a pasta `investiments_br` no Android Studio ou terminal.
3. No terminal, execute:
   ```bash
   flutter create . --platforms=android
   flutter pub get
   flutter build apk --release
   ```
4. O APK será gerado em:
   `build/app/outputs/flutter-apk/app-release.apk`

Para gerar um APK instalável e testar:
```bash
flutter install
```

## Próximas etapas sugeridas
1. Persistência local da carreira.
2. Sistema de contratos, salários e comissões.
3. Calendário e notícias do mercado.
4. Base de dados real e atualizável de jogadores/clubes, com fonte licenciada.
5. Negociações e eventos dinâmicos.
